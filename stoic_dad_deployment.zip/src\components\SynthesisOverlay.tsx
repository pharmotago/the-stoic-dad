"use client";

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Compass, Hammer, Shield } from 'lucide-react';

import { useAgentPulse, AgentBroadcast } from '../lib/useAgentPulse';

const ARCHETYPE = {
    name: "The Patriarch",
    pulseColor: "border-amber-500/10",
    glowColor: "rgba(245,158,11,0.05)",
    pulseDuration: 6,
    tag: "TERMINAL PORT"
};

export function SynthesisOverlay() {
    const messages = useAgentPulse('stoic-dad');
    const [pulseActive, setPulseActive] = useState(false);

    useEffect(() => {
        if (messages.length > 0) {
            setPulseActive(true);
            const timer = setTimeout(() => setPulseActive(false), 6000);
            return () => clearTimeout(timer);
        }
    }, [messages]);

    return (
        <>
            {/* Council Pulse: Monolithic Frequency */}
            <AnimatePresence>
                {pulseActive && (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 1.02 }}
                        transition={{ duration: ARCHETYPE.pulseDuration, ease: [0.4, 0, 0.2, 1] }}
                        className={`fixed inset-0 pointer-events-none z-[100] border-[20px] ${ARCHETYPE.pulseColor} shadow-[inset_0_0_250px_${ARCHETYPE.glowColor}]`}
                    />
                )}
            </AnimatePresence>

            {/* Synthesis Feed: Stoic Intelligence */}
            <div className="fixed top-32 left-1/2 -translate-x-1/2 z-[101] flex flex-col gap-6 pointer-events-none max-w-lg w-full px-4">
                <AnimatePresence>
                    {messages.map((msg) => (
                        <motion.div
                            key={msg.id}
                            initial={{ opacity: 0, y: -20, scale: 0.98 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, scale: 1.05, filter: 'blur(20px)' }}
                            className="p-8 bg-slate-900/90 border-2 border-amber-500/10 rounded-none backdrop-blur-3xl shadow-[0_20px_100px_rgba(0,0,0,0.8)] relative overflow-hidden group pointer-events-auto"
                        >
                            {/* Vertical "Pillar" Decor */}
                            <div className="absolute left-0 top-0 w-1 h-full bg-amber-500/40" />
                            <div className="absolute right-0 top-0 w-1 h-full bg-amber-500/40" />

                            <div className="flex flex-col items-center text-center gap-4">
                                <div className="p-3 bg-amber-500/5 border border-amber-500/20">
                                    {msg.type === 'insight' && <Compass className="w-6 h-6 text-amber-500" />}
                                    {msg.type === 'optimization' && <Hammer className="w-6 h-6 text-amber-600" />}
                                    {msg.type === 'verification' && <Shield className="w-6 h-6 text-amber-700" />}
                                </div>
                                <div className="space-y-2">
                                    <div className="flex items-center justify-center gap-3">
                                        <div className="h-[1px] w-8 bg-amber-500/30" />
                                        <span className="text-[10px] font-black text-amber-500 uppercase tracking-[0.5em]">
                                            {ARCHETYPE.tag}
                                        </span>
                                        <div className="h-[1px] w-8 bg-amber-500/30" />
                                    </div>
                                    <p className="text-sm text-amber-50/60 font-serif leading-relaxed italic">
                                        [{msg.role}]: "{msg.content}"
                                    </p>
                                    <p className="text-[9px] font-bold text-amber-500/40 uppercase tracking-widest mt-2">
                                        — {ARCHETYPE.name} —
                                    </p>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>
        </>
    );
}
