
import { useEffect, useState } from 'react';
import { supabase } from './supabase';

export interface AgentBroadcast {
    id: string;
    role: string;
    content: string;
    type: 'insight' | 'optimization' | 'verification';
    created_at: string;
}

export function useAgentPulse(appName: string) {
    const [messages, setMessages] = useState<AgentBroadcast[]>([]);

    useEffect(() => {
        const channel = supabase
            .channel(`agent_pulse_${appName}`)
            .on(
                'postgres_changes',
                {
                    event: 'INSERT',
                    schema: 'public',
                    table: 'agent_broadcasts',
                    filter: `app_name=eq.${appName}`
                },
                (payload) => {
                    const newBroadcast = payload.new as any;
                    const msg: AgentBroadcast = {
                        id: newBroadcast.id.toString(),
                        role: newBroadcast.role,
                        content: newBroadcast.content,
                        type: newBroadcast.type || 'insight',
                        created_at: newBroadcast.created_at
                    };

                    setMessages(prev => [...prev, msg]);

                    // Auto-remove after 10 seconds to keep UI clean
                    setTimeout(() => {
                        setMessages(prev => prev.filter(m => m.id !== msg.id));
                    }, 10000);
                }
            )
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    }, [appName]);

    return messages;
}
